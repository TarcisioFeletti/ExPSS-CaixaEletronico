/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.caixaeletronico;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author tarci
 */
public class CaixaEletronicoTest {
    
    public CaixaEletronicoTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void CT001(){
        R$100 R$100 = new R$100();
        R$100.calcular(1100);
        assertEquals(11,R$100.getQuantidade());
    }
    @Test
    public void CT002(){
        R$50 R$50 = new R$50();
        R$50.calcular(1100);
        assertEquals(22,R$50.getQuantidade());
    }
    @Test
    public void CT003(){
        R$20 R$20 = new R$20();
        R$20.calcular(1100);
        assertEquals(55,R$20.getQuantidade());
    }
    @Test
    public void CT004(){
        R$10 R$10 = new R$10();
        R$10.calcular(110);
        assertEquals(11,R$10.getQuantidade());
    }
    @Test
    public void CT005(){
        R$5 R$5 = new R$5();
        R$5.calcular(100);
        assertEquals(20,R$5.getQuantidade());
    }
    @Test
    public void CT006(){
        R$2 R$2 = new R$2();
        R$2.calcular(110);
        assertEquals(55,R$2.getQuantidade());
    }
    @Test
    public void CT007(){
        R$1 R$1 = new R$1();
        R$1.calcular(1100);
        assertEquals(1100,R$1.getQuantidade());
    }
    @Test
    public void CT008(){
        R$0_5 R$0_5 = new R$0_5();
        R$0_5.calcular(10);
        assertEquals(20,R$0_5.getQuantidade());
    }
    @Test
    public void CT009(){
        R$0_25 R$100 = new R$0_25();
        R$100.calcular(10);
        assertEquals(40,R$100.getQuantidade());
    }
    @Test
    public void CT010(){
        R$0_1 R$100 = new R$0_1();
        R$100.calcular(10.55);
        assertEquals(105,R$100.getQuantidade());
    }
    @Test
    public void CT011(){
        R$0_05 R$100 = new R$0_05();
        R$100.calcular(10);
        assertEquals(200,R$100.getQuantidade());
    }
}
