/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.pss.caixaeletronico;

/**
 *
 * @author tarci
 */
public class Cédulas {
    
}

class R$100 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/100);
        return valor%100;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$50 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/50);
        return valor%50;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$20 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/20);
        return valor%20;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$10 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/10);
        return valor%10;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$5 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/5);
        return valor%5;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$2 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/2);
        return valor%2;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$1 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/1);
        return valor%1;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$0_5 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/0.5);
        return valor%0.5;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$0_25 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/0.25);
        return valor%0.25;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$0_1 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/0.10);
        return valor%0.10;
    }

    public int getQuantidade() {
        return quantidade;
    }
}

class R$0_05 implements IDinheiro{
    private int quantidade;
    @Override
    public double calcular(double valor){
        this.quantidade = (int)(valor/0.05);
        return valor%0.05;
    }

    public int getQuantidade() {
        return quantidade;
    }
}
